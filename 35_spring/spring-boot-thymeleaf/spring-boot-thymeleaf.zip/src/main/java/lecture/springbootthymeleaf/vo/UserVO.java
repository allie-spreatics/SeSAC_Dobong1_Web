package lecture.springbootthymeleaf.vo;

import lombok.Getter;

@Getter
public class UserVO {
    private String name;
    private int age;
}