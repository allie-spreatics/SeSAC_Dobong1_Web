package lecture.springbootthymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
